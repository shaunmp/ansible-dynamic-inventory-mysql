CREATE VIEW inventory AS
  SELECT
    `ansible_inventory`.`group`.`name`     AS `group`,
    `ansible_inventory`.`host`.`host`      AS `host`,
    `ansible_inventory`.`host`.`hostname`  AS `hostname`,
    `ansible_inventory`.`host`.`variables` AS `host_vars`
  FROM (`ansible_inventory`.`group`
    LEFT JOIN (`ansible_inventory`.`host`
      LEFT JOIN `ansible_inventory`.`hostgroups`
        ON ((`ansible_inventory`.`host`.`id` = `ansible_inventory`.`hostgroups`.`host_id`)))
      ON ((`ansible_inventory`.`hostgroups`.`group_id` = `ansible_inventory`.`group`.`id`)))
  WHERE ((`ansible_inventory`.`host`.`enabled` = 1) AND (`ansible_inventory`.`group`.`enabled` = 1))
  ORDER BY `ansible_inventory`.`host`.`hostname`;
