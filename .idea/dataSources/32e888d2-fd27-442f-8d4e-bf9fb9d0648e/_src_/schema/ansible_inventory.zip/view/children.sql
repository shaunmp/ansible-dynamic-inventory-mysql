CREATE VIEW children AS
  SELECT
    `gparent`.`name` AS `parent`,
    `gchild`.`name`  AS `child`
  FROM ((`ansible_inventory`.`childgroups`
    LEFT JOIN `ansible_inventory`.`group` `gparent`
      ON ((`ansible_inventory`.`childgroups`.`parent_id` = `gparent`.`id`))) LEFT JOIN
    `ansible_inventory`.`group` `gchild` ON ((`ansible_inventory`.`childgroups`.`child_id` = `gchild`.`id`)))
  ORDER BY `gparent`.`name`;
